import { Component } from '@angular/core';

@Component({
  selector: 'app-category-form',
  imports: [],
  templateUrl: './category-form.component.html',
  styleUrl: './category-form.component.scss'
})
export class CategoryFormComponent {

}
