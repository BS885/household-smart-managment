export const environment = {
    production: true,
    apiUrl: 'https://household-smart-managment-api.onrender.com/api'
};